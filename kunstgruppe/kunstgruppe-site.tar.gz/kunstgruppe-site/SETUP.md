# Quick Setup Guide - Kunst Gruppe Bureau

## Prerequisites Checklist

- [ ] Google Cloud account with billing enabled
- [ ] Domain registered (kunstgruppe.com)
- [ ] reCAPTCHA v3 keys created
- [ ] Node.js 18+ installed
- [ ] Google Cloud SDK installed

## Step-by-Step Setup

### 1. reCAPTCHA Setup (5 minutes)

1. Go to https://www.google.com/recaptcha/admin
2. Create new site:
   - Label: "Kunst Gruppe Bureau"
   - reCAPTCHA type: Score based (v3)
   - Domains: `kunstgruppe.com`, `localhost`
3. Save site key and secret key

### 2. Google Cloud Project (10 minutes)

```bash
# Set variables
export PROJECT_ID="kunstgruppe-site"
export REGION="us-central1"

# Create project
gcloud projects create $PROJECT_ID
gcloud config set project $PROJECT_ID

# Enable APIs
gcloud services enable cloudfunctions.googleapis.com \
  sheets.googleapis.com \
  storage.googleapis.com \
  compute.googleapis.com
```

### 3. Service Account (5 minutes)

```bash
# Create service account
gcloud iam service-accounts create kunstgruppe-sheets \
  --display-name="Kunstgruppe Sheets"

# Generate key
gcloud iam service-accounts keys create ~/kunstgruppe-key.json \
  --iam-account=kunstgruppe-sheets@$PROJECT_ID.iam.gserviceaccount.com

# Grant permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:kunstgruppe-sheets@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/editor"
```

### 4. Google Sheet (5 minutes)

1. Create new Google Sheet: "Kunstgruppe Contact Forms"
2. Rename first tab: "Form Submissions"
3. Add header row: `Timestamp | Name | Email | Subject | Message | reCAPTCHA Score`
4. Share with `kunstgruppe-sheets@$PROJECT_ID.iam.gserviceaccount.com` (Editor)
5. Copy Sheet ID from URL

### 5. Deploy Cloud Function (5 minutes)

```bash
cd functions

gcloud functions deploy submitContactForm \
  --runtime=nodejs18 \
  --trigger-http \
  --allow-unauthenticated \
  --region=$REGION \
  --set-env-vars RECAPTCHA_SECRET_KEY="YOUR_SECRET_KEY" \
  --set-env-vars GOOGLE_SHEET_ID="YOUR_SHEET_ID" \
  --set-env-vars GOOGLE_SERVICE_ACCOUNT_KEY="$(cat ~/kunstgruppe-key.json | tr -d '\n')"

# Get function URL
gcloud functions describe submitContactForm \
  --region=$REGION \
  --format="value(httpsTrigger.url)"
```

### 6. Configure Environment (2 minutes)

Create `.env` in project root:

```bash
REACT_APP_RECAPTCHA_SITE_KEY=your_site_key_here
REACT_APP_CLOUD_FUNCTION_URL=https://YOUR-REGION-YOUR-PROJECT.cloudfunctions.net/submitContactForm
```

### 7. Test Locally (2 minutes)

```bash
npm install
npm start
# Visit http://localhost:3000
# Test form submission
```

### 8. Setup Cloud Storage (10 minutes)

```bash
# Create bucket
gsutil mb -p $PROJECT_ID -c STANDARD -l US gs://kunstgruppe.com

# Configure as website
gsutil web set -m index.html -e index.html gs://kunstgruppe.com

# Make public
gsutil iam ch allUsers:objectViewer gs://kunstgruppe.com

# Create backend bucket
gcloud compute backend-buckets create kunstgruppe-backend \
  --gcs-bucket-name=kunstgruppe.com \
  --enable-cdn

# Create URL map
gcloud compute url-maps create kunstgruppe-lb \
  --default-backend-bucket=kunstgruppe-backend
```

### 9. Setup SSL & Load Balancer (15 minutes)

```bash
# Request SSL certificate
gcloud compute ssl-certificates create kunstgruppe-cert \
  --domains=kunstgruppe.com,www.kunstgruppe.com \
  --global

# Create HTTPS proxy
gcloud compute target-https-proxies create kunstgruppe-https-proxy \
  --url-map=kunstgruppe-lb \
  --ssl-certificates=kunstgruppe-cert

# Reserve IP
gcloud compute addresses create kunstgruppe-ip --global

# Get IP address
IP=$(gcloud compute addresses describe kunstgruppe-ip --global --format="value(address)")
echo "Your IP address: $IP"

# Create forwarding rule
gcloud compute forwarding-rules create kunstgruppe-https \
  --address=kunstgruppe-ip \
  --target-https-proxy=kunstgruppe-https-proxy \
  --global \
  --ports=443
```

### 10. Configure DNS (5 minutes)

Add DNS records at your domain registrar:

```
Type  Name                    Value
A     kunstgruppe.com         [IP from step 9]
A     www.kunstgruppe.com     [IP from step 9]
```

**Wait 5-10 minutes for DNS propagation**

### 11. Deploy Site (2 minutes)

```bash
# Build and deploy
./deploy.sh

# Or manually
npm run build
gsutil -m rsync -r -d build/ gs://kunstgruppe.com
gcloud compute url-maps invalidate-cdn-cache kunstgruppe-lb --path "/*"
```

### 12. Verify (5 minutes)

- [ ] Visit https://kunstgruppe.com (may take 10-60 minutes for SSL)
- [ ] Test all navigation links
- [ ] Submit contact form
- [ ] Check Google Sheet for submission
- [ ] Check Cloud Function logs

## Total Setup Time: ~70 minutes

## Common Issues

**SSL Certificate Provisioning**
- Takes 10-60 minutes after DNS propagation
- Check status: `gcloud compute ssl-certificates describe kunstgruppe-cert --global`

**Form Not Submitting**
- Check browser console
- Verify Cloud Function URL in `.env`
- Check function logs: `gcloud functions logs read submitContactForm`

**DNS Not Resolving**
- Allow 5-10 minutes for propagation
- Verify with: `dig kunstgruppe.com`

## Next Steps

1. Monitor form submissions in Google Sheet
2. Set up alerts for function errors
3. Review CDN cache performance
4. Configure backup strategy

## Cost Monitoring

```bash
# View current month costs
gcloud billing accounts list
gcloud billing projects describe $PROJECT_ID
```

Expected monthly cost: < $5 for moderate traffic
