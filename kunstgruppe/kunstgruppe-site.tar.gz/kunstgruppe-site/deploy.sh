#!/bin/bash

# Kunst Gruppe Bureau - Deployment Script
# Builds and deploys the React site to Google Cloud Storage with CDN cache invalidation

set -e  # Exit on error

echo "🎨 Kunst Gruppe Bureau - Deployment Script"
echo "=========================================="

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    echo "❌ Error: gcloud CLI not found. Please install Google Cloud SDK."
    exit 1
fi

# Check if PROJECT_ID is set
if [ -z "$PROJECT_ID" ]; then
    echo "⚠️  PROJECT_ID not set. Using default gcloud project..."
    PROJECT_ID=$(gcloud config get-value project)
fi

echo "📦 Project: $PROJECT_ID"
echo ""

# Build
echo "🔨 Building React application..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Build failed!"
    exit 1
fi

echo "✅ Build completed successfully"
echo ""

# Sync to Cloud Storage
echo "☁️  Deploying to gs://kunstgruppe.com..."
gsutil -m rsync -r -d build/ gs://kunstgruppe.com

if [ $? -ne 0 ]; then
    echo "❌ Deployment failed!"
    exit 1
fi

echo "✅ Deployment completed successfully"
echo ""

# Invalidate CDN cache
echo "🔄 Invalidating CDN cache..."
gcloud compute url-maps invalidate-cdn-cache kunstgruppe-lb --path "/*" --quiet

if [ $? -ne 0 ]; then
    echo "⚠️  CDN cache invalidation failed (non-critical)"
else
    echo "✅ CDN cache invalidated"
fi

echo ""
echo "🎉 Deployment complete!"
echo "🌐 Site: https://kunstgruppe.com"
echo ""
