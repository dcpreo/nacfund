# Deployment Checklist - Kunst Gruppe Bureau

Use this checklist to ensure nothing is missed during deployment.

## Pre-Deployment

### Configuration
- [ ] Created `.env` file from `.env.example`
- [ ] Added reCAPTCHA site key to `.env`
- [ ] Added Cloud Function URL to `.env`
- [ ] Verified all environment variables are correct

### Testing
- [ ] Ran `npm install` successfully
- [ ] Ran `npm start` - site loads at localhost:3000
- [ ] Tested navigation - all sections scroll correctly
- [ ] Tested form submission locally
- [ ] Verified form data appears in Google Sheet
- [ ] Checked browser console - no errors

## Google Cloud Setup

### Project & APIs
- [ ] Created Google Cloud project
- [ ] Enabled Cloud Functions API
- [ ] Enabled Sheets API  
- [ ] Enabled Cloud Storage API
- [ ] Enabled Compute Engine API
- [ ] Confirmed billing is enabled

### Service Account
- [ ] Created service account
- [ ] Downloaded service account key JSON
- [ ] Granted editor role to service account
- [ ] Shared Google Sheet with service account email

### Cloud Function
- [ ] Deployed Cloud Function successfully
- [ ] Set all environment variables (3 total)
- [ ] Tested function with curl/Postman
- [ ] Verified function writes to Google Sheet
- [ ] Confirmed function URL is correct

### Storage & CDN
- [ ] Created Cloud Storage bucket `kunstgruppe.com`
- [ ] Configured bucket as website
- [ ] Made bucket public
- [ ] Created backend bucket with CDN enabled
- [ ] Created URL map
- [ ] Requested SSL certificate
- [ ] Created HTTPS proxy
- [ ] Reserved static IP address
- [ ] Created forwarding rule

### DNS
- [ ] Added A record for kunstgruppe.com
- [ ] Added A record for www.kunstgruppe.com
- [ ] Verified DNS propagation (5-10 minutes)
- [ ] Confirmed SSL certificate provisioned (10-60 minutes)

## Initial Deployment

### Build & Deploy
- [ ] Ran `npm run build` - build succeeded
- [ ] Deployed to Cloud Storage: `gsutil rsync`
- [ ] Invalidated CDN cache
- [ ] Waited for cache propagation (2-5 minutes)

## Post-Deployment Verification

### Site Functionality
- [ ] Site loads at https://kunstgruppe.com
- [ ] SSL certificate valid (green padlock)
- [ ] All five projects display correctly
- [ ] Navigation menu works on desktop
- [ ] Navigation menu works on mobile
- [ ] Contact form displays correctly
- [ ] reCAPTCHA loads without errors

### Form Testing
- [ ] Submitted test form with valid data
- [ ] Received success message
- [ ] Form data appeared in Google Sheet with timestamp
- [ ] reCAPTCHA score recorded (should be > 0.5)
- [ ] Tested form validation (empty fields)
- [ ] Tested form with invalid email

### Cross-Browser Testing
- [ ] Tested in Chrome
- [ ] Tested in Firefox  
- [ ] Tested in Safari
- [ ] Tested on mobile device

### Performance
- [ ] Page loads in < 3 seconds
- [ ] Images load properly
- [ ] No console errors
- [ ] Smooth scrolling works

## Monitoring Setup

### Logs & Alerts
- [ ] Verified Cloud Function logs: `gcloud functions logs read submitContactForm`
- [ ] Set up email notifications for function errors (optional)
- [ ] Bookmarked Google Sheet for form monitoring
- [ ] Set up billing alerts in Google Cloud Console

### Documentation
- [ ] Saved `.env` file securely (NOT in Git)
- [ ] Documented service account key location
- [ ] Noted Google Sheet ID
- [ ] Recorded static IP address

## Maintenance

### Regular Tasks
- [ ] Check form submissions weekly
- [ ] Monitor Cloud Function errors
- [ ] Review billing monthly
- [ ] Update dependencies quarterly

### Future Updates
- [ ] To update content: Edit components, run `./deploy.sh`
- [ ] To add projects: Edit `src/components/Projects.js`
- [ ] To change styling: Edit `src/styles/App.css`
- [ ] To update Cloud Function: Redeploy with `gcloud functions deploy`

## Rollback Plan

If deployment fails:

1. **Check Cloud Function logs**:
   ```bash
   gcloud functions logs read submitContactForm --limit=50
   ```

2. **Verify environment variables**:
   ```bash
   gcloud functions describe submitContactForm --format="value(environmentVariables)"
   ```

3. **Redeploy previous version**:
   ```bash
   # React site
   git checkout [previous-commit]
   npm run build
   gsutil rsync -r build/ gs://kunstgruppe.com
   
   # Cloud Function
   cd functions
   gcloud functions deploy submitContactForm [same flags as before]
   ```

4. **Clear CDN cache**:
   ```bash
   gcloud compute url-maps invalidate-cdn-cache kunstgruppe-lb --path "/*"
   ```

## Support Resources

- **Google Cloud Console**: https://console.cloud.google.com
- **Cloud Function Logs**: Cloud Console > Cloud Functions > submitContactForm > Logs
- **Storage Browser**: Cloud Console > Cloud Storage > kunstgruppe.com
- **Billing**: Cloud Console > Billing
- **DNS Tools**: https://dnschecker.org
- **SSL Check**: https://www.ssllabs.com/ssltest/

## Contact Information

For technical issues:
1. Check Cloud Function logs
2. Verify environment variables
3. Test form locally
4. Review Google Sheet permissions

---

**Deployment Date**: _______________
**Deployed By**: _______________
**Version**: 1.0.0
