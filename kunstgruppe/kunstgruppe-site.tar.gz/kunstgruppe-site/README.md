# Kunst Gruppe Bureau Website

Professional art infrastructure network website built with React and deployed on Google Cloud.

## Architecture

- **Frontend**: React single-page application
- **Backend**: Google Cloud Function (Node.js 18)
- **Form Storage**: Google Sheets API
- **Security**: reCAPTCHA v3
- **Hosting**: Google Cloud Storage + Cloud CDN

## Local Development

### Prerequisites

- Node.js 18+
- Google Cloud SDK
- Google Cloud Project with billing enabled

### Setup

1. **Clone and install dependencies**:
```bash
npm install
```

2. **Create `.env` file** (copy from `.env.example`):
```bash
cp .env.example .env
```

3. **Configure reCAPTCHA**:
   - Go to https://www.google.com/recaptcha/admin
   - Create v3 site for `localhost` and `kunstgruppe.com`
   - Add site key to `.env` as `REACT_APP_RECAPTCHA_SITE_KEY`

4. **Run development server**:
```bash
npm start
```

## Google Cloud Setup

### 1. Create Google Cloud Project

```bash
# Set your project ID
PROJECT_ID="kunstgruppe-site"

# Create project
gcloud projects create $PROJECT_ID --name="Kunst Gruppe Bureau"

# Set as active project
gcloud config set project $PROJECT_ID

# Enable required APIs
gcloud services enable cloudfunctions.googleapis.com
gcloud services enable sheets.googleapis.com
gcloud services enable storage.googleapis.com
gcloud services enable compute.googleapis.com
```

### 2. Create Service Account

```bash
# Create service account
gcloud iam service-accounts create kunstgruppe-sheets \
  --display-name="Kunst Gruppe Sheets Access"

# Create and download key
gcloud iam service-accounts keys create ~/kunstgruppe-key.json \
  --iam-account=kunstgruppe-sheets@$PROJECT_ID.iam.gserviceaccount.com

# Grant Sheets API access
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:kunstgruppe-sheets@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/editor"
```

### 3. Create Google Sheet

1. Create new Google Sheet named "Kunst Gruppe Contact Forms"
2. Create sheet tab named "Form Submissions"
3. Add headers: `Timestamp | Name | Email | Subject | Message | reCAPTCHA Score`
4. Share sheet with service account email: `kunstgruppe-sheets@$PROJECT_ID.iam.gserviceaccount.com` (Editor access)
5. Copy Sheet ID from URL (between `/d/` and `/edit`)

### 4. Deploy Cloud Function

```bash
cd functions

# Deploy function
gcloud functions deploy submitContactForm \
  --runtime=nodejs18 \
  --trigger-http \
  --allow-unauthenticated \
  --region=us-central1 \
  --set-env-vars RECAPTCHA_SECRET_KEY="your_secret_key" \
  --set-env-vars GOOGLE_SHEET_ID="your_sheet_id" \
  --set-env-vars GOOGLE_SERVICE_ACCOUNT_KEY="$(cat ~/kunstgruppe-key.json | tr -d '\n')"

# Get function URL
gcloud functions describe submitContactForm --region=us-central1 --format="value(httpsTrigger.url)"
```

Update `.env` with the function URL as `REACT_APP_CLOUD_FUNCTION_URL`.

### 5. Create Cloud Storage Bucket

```bash
# Create bucket
gsutil mb -p $PROJECT_ID -c STANDARD -l US gs://kunstgruppe.com

# Enable website configuration
gsutil web set -m index.html -e index.html gs://kunstgruppe.com

# Make bucket public
gsutil iam ch allUsers:objectViewer gs://kunstgruppe.com
```

### 6. Setup Cloud CDN

```bash
# Create backend bucket
gcloud compute backend-buckets create kunstgruppe-backend \
  --gcs-bucket-name=kunstgruppe.com \
  --enable-cdn

# Create URL map
gcloud compute url-maps create kunstgruppe-lb \
  --default-backend-bucket=kunstgruppe-backend

# Create SSL certificate
gcloud compute ssl-certificates create kunstgruppe-cert \
  --domains=kunstgruppe.com,www.kunstgruppe.com \
  --global

# Create target HTTPS proxy
gcloud compute target-https-proxies create kunstgruppe-https-proxy \
  --url-map=kunstgruppe-lb \
  --ssl-certificates=kunstgruppe-cert

# Reserve static IP
gcloud compute addresses create kunstgruppe-ip --global

# Get IP address
gcloud compute addresses describe kunstgruppe-ip --global --format="value(address)"

# Create forwarding rule
gcloud compute forwarding-rules create kunstgruppe-https \
  --address=kunstgruppe-ip \
  --target-https-proxy=kunstgruppe-https-proxy \
  --global \
  --ports=443
```

### 7. Configure DNS

Add these records to your domain registrar:

```
A     kunstgruppe.com     →  [IP from previous step]
A     www.kunstgruppe.com →  [IP from previous step]
```

### 8. Deploy Website

```bash
# Build production bundle
npm run build

# Deploy to Cloud Storage
gsutil -m rsync -r -d build/ gs://kunstgruppe.com

# Invalidate CDN cache
gcloud compute url-maps invalidate-cdn-cache kunstgruppe-lb --path "/*"
```

Or use the npm script:
```bash
npm run deploy
```

## Environment Variables

### Frontend (.env)

- `REACT_APP_RECAPTCHA_SITE_KEY`: reCAPTCHA v3 site key
- `REACT_APP_CLOUD_FUNCTION_URL`: Cloud Function endpoint URL

### Backend (Cloud Function)

- `RECAPTCHA_SECRET_KEY`: reCAPTCHA v3 secret key
- `GOOGLE_SHEET_ID`: Google Sheets ID for form submissions
- `GOOGLE_SERVICE_ACCOUNT_KEY`: Service account JSON key (as string)

## Project Structure

```
kunstgruppe-site/
├── public/
│   └── index.html          # HTML template
├── src/
│   ├── components/
│   │   ├── Header.js       # Navigation
│   │   ├── Hero.js         # Hero section
│   │   ├── About.js        # About section
│   │   ├── Projects.js     # Projects grid
│   │   ├── Contact.js      # Contact form
│   │   └── Footer.js       # Footer
│   ├── styles/
│   │   └── App.css         # Main stylesheet
│   ├── App.js              # Main component
│   └── index.js            # Entry point
├── functions/
│   ├── index.js            # Cloud Function
│   └── package.json        # Function dependencies
├── .env.example            # Environment template
├── package.json            # Dependencies
└── README.md              # This file
```

## Updating Content

### Adding New Projects

Edit `src/components/Projects.js` and add to the `projects` array:

```javascript
{
  icon: '🎨',
  title: 'Project Name',
  description: 'Project description...',
  url: 'https://example.com',
  category: 'Category',
  role: 'Your Role'
}
```

### Modifying Sections

- **Hero**: Edit `src/components/Hero.js`
- **About**: Edit `src/components/About.js`
- **Contact**: Edit `src/components/Contact.js`
- **Footer**: Edit `src/components/Footer.js`

### Styling

Edit `src/styles/App.css` - CSS variables are defined in `:root` for easy theming.

## Monitoring

### View Form Submissions

Open your Google Sheet to see all form submissions with timestamps and reCAPTCHA scores.

### Check Cloud Function Logs

```bash
gcloud functions logs read submitContactForm --region=us-central1
```

### Monitor CDN Performance

```bash
gcloud compute backend-buckets describe kunstgruppe-backend
```

## Troubleshooting

### Form not submitting

1. Check browser console for errors
2. Verify Cloud Function URL in `.env`
3. Check Cloud Function logs: `gcloud functions logs read submitContactForm`
4. Verify reCAPTCHA keys are correct

### 404 errors on page refresh

Cloud Storage static hosting doesn't support SPA routing. All routes return `index.html` by design.

### CDN cache issues

Invalidate cache after deployment:
```bash
gcloud compute url-maps invalidate-cdn-cache kunstgruppe-lb --path "/*"
```

## Security

- reCAPTCHA v3 protects against spam (score threshold: 0.5)
- CORS enabled for Cloud Function
- Service account has minimal necessary permissions
- HTTPS enforced via Cloud CDN

## Cost Estimate

- Cloud Storage: ~$0.02/GB/month
- Cloud CDN: ~$0.08-0.12/GB egress
- Cloud Functions: First 2M invocations free
- Google Sheets API: Free
- SSL Certificate: Free (Google-managed)

Expected monthly cost for moderate traffic: < $5

## Support

For issues or questions, contact via the website form or open an issue.
