import React from 'react';

function Projects() {
  const projects = [
    {
      icon: '💾',
      title: 'Hardware Art Inventory Database',
      description: 'Contemporary art inventory database incorporating AI with integrated provenance compliance system—professional inventory management for galleries and collectors.',
      url: 'https://hardwarearts.com',
      category: 'Gallery & SaaS Platform',
      role: 'Founder'
    },
    {
      icon: '🏛️',
      title: 'Shchukin Foundation',
      description: 'Preserving and promoting the legacy of the Shchukin collection—one of the most important private art collections in history. New York operations.',
      url: 'https://shchukin.org',
      category: 'Cultural Foundation',
      role: 'Advisor'
    },
    {
      icon: '🎨',
      title: 'National Art Collections Foundation',
      description: 'Russian cultural foundation preserving art traditions through exhibitions, authentication services, and institutional partnerships since 1988.',
      url: 'https://nacfund.org',
      category: 'Cultural Foundation',
      role: 'Board Member'
    },
    {
      icon: '🎭',
      title: 'Artmedia Agency',
      description: 'Premier fine art brokerage and media consultancy connecting Russian and international collectors, artists, and institutions.',
      url: 'https://artmedia.ru',
      category: 'Art Brokerage & Media',
      role: 'Stakeholder'
    },
    {
      icon: '🔨',
      title: 'Bad Penny Fine Art Acquisitions',
      description: 'Discreet acquisitions and advisory for collectors and institutions. Strategic sourcing, due diligence, and transaction execution in the secondary market—where timing and intelligence matter more than visibility.',
      url: 'https://badpenny.art',
      category: 'Fine Art Acquisitions',
      role: 'Partner'
    }
  ];

  return (
    <section id="projects" className="projects">
      <div className="container">
        <h2 className="section-title">Our Projects</h2>
        <p className="section-subtitle">
          Five distinct initiatives working together to advance art documentation, 
          acquisitions, and cultural preservation
        </p>
        <div className="projects-grid">
          {projects.map((project, index) => (
            <div key={index} className="project-card">
              <div className="project-icon">{project.icon}</div>
              <h3 className="project-title">{project.title}</h3>
              <p className="project-description">{project.description}</p>
              <div className="project-meta">
                <a 
                  href={project.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="project-link"
                >
                  {project.url.replace('https://', '')}
                </a>
                <div className="project-tags">
                  <span className="project-category">{project.category}</span>
                  <span className="project-role">{project.role}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
