import React from 'react';

function Footer() {
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="footer-title">Kunst Gruppe Bureau</h3>
            <p className="footer-description">
              Professional art infrastructure network spanning gallery technology, 
              cultural preservation, and international markets.
            </p>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-heading">Projects</h4>
            <ul className="footer-links">
              <li><a href="https://hardwarearts.com" target="_blank" rel="noopener noreferrer">Hardware Art Database</a></li>
              <li><a href="https://shchukin.org" target="_blank" rel="noopener noreferrer">Shchukin Foundation</a></li>
              <li><a href="https://nacfund.org" target="_blank" rel="noopener noreferrer">NAC Fund</a></li>
              <li><a href="https://artmedia.ru" target="_blank" rel="noopener noreferrer">Artmedia Agency</a></li>
              <li><a href="https://badpenny.art" target="_blank" rel="noopener noreferrer">Bad Penny</a></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-heading">Contact</h4>
            <p className="footer-text">
              For inquiries about our projects and collaborations.
            </p>
            <button onClick={() => scrollToSection('contact')} className="footer-contact-btn">
              Get in Touch
            </button>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; 2025 Kunst Gruppe Bureau. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
