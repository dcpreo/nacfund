import React from 'react';

function Hero() {
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="hero">
      <div className="container">
        <h1 className="hero-title">Art & Culture Network</h1>
        <p className="hero-subtitle">
          Professional infrastructure spanning gallery technology, cultural preservation, 
          and international art markets
        </p>
        <div className="hero-actions">
          <button onClick={() => scrollToSection('projects')} className="btn btn-primary">
            Explore Projects
          </button>
          <button onClick={() => scrollToSection('about')} className="btn btn-secondary">
            Learn More
          </button>
        </div>
      </div>
    </section>
  );
}

export default Hero;
