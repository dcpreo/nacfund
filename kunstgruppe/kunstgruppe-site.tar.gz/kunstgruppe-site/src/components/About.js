import React from 'react';

function About() {
  return (
    <section id="about" className="about">
      <div className="container">
        <h2 className="section-title">About Kunst Gruppe Bureau</h2>
        <p className="section-description">
          Kunst Gruppe Bureau represents a professional network of art world infrastructure 
          projects—from contemporary gallery technology to Russian cultural heritage 
          preservation. These interconnected ventures bridge Eastern and Western art markets 
          through institutional partnerships, authentication services, and innovative 
          inventory systems.
        </p>
        <div className="about-pillars">
          <div className="pillar">
            <div className="pillar-icon">🎨</div>
            <h3 className="pillar-title">Art Documentation</h3>
            <p className="pillar-description">
              Enterprise-grade provenance tracking and inventory management powered by AI research tools
            </p>
          </div>
          <div className="pillar">
            <div className="pillar-icon">🌐</div>
            <h3 className="pillar-title">Digital Innovation</h3>
            <p className="pillar-description">
              Bridging Russian avant-garde heritage with contemporary gallery infrastructure
            </p>
          </div>
          <div className="pillar">
            <div className="pillar-icon">🏛️</div>
            <h3 className="pillar-title">Cultural Heritage</h3>
            <p className="pillar-description">
              Shchukin collection stewardship and Russian art market intelligence
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;
